<?php

namespace Database\Seeders;

use App\Models\Role;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // php artisan db:seed --class=RoleSeeder

        // $role1 = new Role();
        // $role1->libelle = "Membre";
        // $role1->save();

        // $role2 = new Role();
        // $role2->libelle = "Conseil d'administration";
        // $role2->save();
        
    }
}
