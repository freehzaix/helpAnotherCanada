<?php $__env->startSection('titlePage'); ?>
    Tableau de bord
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentPage'); ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"><?php echo $__env->yieldContent('titlePage'); ?></h1>
        </div>
        <!-- Content Row -->
        <div class="row">
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <div class="card shadow mb-4">
                    <!-- Card Body -->
                    <div class="card-body">
                        <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium corrupti, nihil, dolor
                            soluta impedit
                            perferendis odit maiores inventore quo voluptas nobis in. Minima nostrum necessitatibus
                            dignissimos!
                            Temporibus suscipit neque tempore.
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AP2S\Videos\HelpOneAnother\membreconseil\resources\views/dashboard.blade.php ENDPATH**/ ?>