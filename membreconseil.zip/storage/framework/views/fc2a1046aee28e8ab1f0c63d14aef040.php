<?php $__env->startSection('titlePage'); ?>
    Nos Webinaires
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentPage'); ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <div class="col">
                <h1 class="h3 mb-0 text-gray-800"><?php echo $__env->yieldContent('titlePage'); ?></h1>
            </div>
            <div class="col-3">
                <?php if(Auth::user()->role->id == 2): ?>
                    <a href="<?php echo e(route('webinaire.create')); ?>" class="btn btn-primary btn-user btn-block mt-3">Créer un Webinaire</a>
                <?php endif; ?>
            </div>
        </div>
        <!-- Content Row -->
        <div class="row">

            <?php $__currentLoopData = $webinaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <div class="col">
                        <div class="card shadow mb-3">
                            <div class="card-image">
                                <img src="./storage/<?php echo e($row->image_webinaire); ?>" width="320px" alt="">
                            </div>
                            <!-- Card Body -->
                            <div class="card-body">
                                <h2><?php echo e($row->designation); ?></h2>
                                <p><?php echo e($row->description); ?></p>
                                <a href="<?php echo e($row->url_webinaire); ?>" class="btn btn-primary" target="_blank">Participer</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AP2S\Videos\HelpOneAnother\membreconseil\resources\views/webinaire/index.blade.php ENDPATH**/ ?>