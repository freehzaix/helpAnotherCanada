<?php $__env->startSection('titlePage'); ?>
    Annuaire d'entreprise
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentPage'); ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <div class="col">
                <h1 class="h3 mb-0 text-gray-800"><?php echo $__env->yieldContent('titlePage'); ?></h1>
            </div>
            <div class="col-3">
                <a href="<?php echo e(route('annuaire.create')); ?>" class="btn btn-primary btn-user btn-block mt-3">Créer un annuaire</a>
            </div>
        </div>
        <!-- Content Row -->
        <div class="row">
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <div class="card shadow mb-4">
                    <!-- Card Body -->
                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success"> <?php echo e(session('status')); ?> </div>
                        <?php endif; ?>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Nom d'entreprise</th>
                                    <th>Ville</th>
                                    <th>Pays</th>
                                    <th>Téléphone</th>
                                    <th>Status</th>
                                    <th>Logo</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $annuaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($row->id); ?></td>
                                        <td><?php echo e($row->nom_entreprise); ?></td>
                                        <td><?php echo e($row->ville); ?></td>
                                        <td><?php echo e($row->pays); ?></td>
                                        <td><?php echo e($row->telephone); ?></td>
                                        <td>
                                            <?php if($row->status): ?>
                                                Approuvé
                                            <?php else: ?>
                                                En attente
                                            <?php endif; ?>
                                        </td>
                                        <td><img src="<?php echo e($row->logo); ?>" height="30px" /></td>
                                        <td>
                                            <a href="/annuaire/<?php echo e($row->id); ?>/show" class="btn btn-info">Modifier</a>
                                            <?php if(Auth::user()->role_id == 2): ?>
                                                <a href="#" class="btn btn-danger">Supprimer</a>
                                            <?php endif; ?>
                                            <?php if(Auth::user()->role_id == 2 && $row->status == false): ?>
                                                <a href="/annuaire/<?php echo e($row->id); ?>/approuve"
                                                    class="btn btn-primary">Approuver</a>
                                            <?php endif; ?>
                                            <?php if(Auth::user()->role_id == 2 && $row->status == true): ?>
                                                <a href="/annuaire/<?php echo e($row->id); ?>/deapprouve"
                                                    class="btn btn-primary">Désapprouver</a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AP2S\Videos\HelpOneAnother\membreconseil\resources\views/annuaire/index.blade.php ENDPATH**/ ?>