<div>
    <h2>Confirmation d'inscription</h2>
    <p>
        Bonjour {{ $user->nom }} et bienvenu(e) sur <a href="http://pwoi.ca">pwoi.ca</a>.
    </p>
    <p>
        Vous inscription a bien été effectué. Vous pouvez vous connection sur le portail membre.
    </p>
</div>